/**
 * Spring Security configuration.
 */
package com.mycompany.bibliotheque.security;
