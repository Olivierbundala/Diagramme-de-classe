/**
 * Spring Framework configuration files.
 */
package com.mycompany.bibliotheque.config;
