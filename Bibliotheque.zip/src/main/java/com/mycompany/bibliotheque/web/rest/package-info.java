/**
 * Spring MVC REST controllers.
 */
package com.mycompany.bibliotheque.web.rest;
