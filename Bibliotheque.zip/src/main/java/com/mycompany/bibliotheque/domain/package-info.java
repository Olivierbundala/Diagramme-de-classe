/**
 * JPA domain objects.
 */
package com.mycompany.bibliotheque.domain;
