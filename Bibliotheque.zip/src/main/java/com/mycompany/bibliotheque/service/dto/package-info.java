/**
 * Data Transfer Objects.
 */
package com.mycompany.bibliotheque.service.dto;
