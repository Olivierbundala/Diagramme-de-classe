/**
 * Service layer beans.
 */
package com.mycompany.bibliotheque.service;
