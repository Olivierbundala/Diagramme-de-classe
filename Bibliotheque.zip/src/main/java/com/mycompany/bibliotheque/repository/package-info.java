/**
 * Spring Data JPA repositories.
 */
package com.mycompany.bibliotheque.repository;
